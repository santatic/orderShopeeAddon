app.controller("homeCtrl", function ($scope) {
    $scope.msg = "day la trnag chu";

});