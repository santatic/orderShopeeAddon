app.service('message_center', function() {
    //lắng nghe 
    this.myFunc = function (x) {
        return x.toString(16);
    }
});